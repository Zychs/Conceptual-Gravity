# legacy adapters
