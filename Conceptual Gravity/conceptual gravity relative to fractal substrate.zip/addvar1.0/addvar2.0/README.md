# addvar2.0

This is a copy of the addvar workspace created for `addvar2.0`.

Quick start (PowerShell):

```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
pytest -q
```

Run the service:
```powershell
uvicorn src.addvar.main:app --reload
```
