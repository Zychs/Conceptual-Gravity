from src.legacy.addvar_adapter import reconcile_adapter


def test_reconcile_adapter_basic(tmp_path):
    coherence_vector = [{'id': 'a'}, {'id': 'b'}]
    deltas = {'added': [{'id': 'c'}], 'removed': [], 'changed': []}
    res = reconcile_adapter(coherence_vector, deltas)
    # legacy reconcile writes a file and returns a summary dict
    assert isinstance(res, dict)
    assert 'generated_at' in res or 'error' in res
