from src.addvar.main import map_query


def test_map_query_basic():
    logs = [
        {"domain": "alpha", "text": "The quick brown fox"},
        {"domain": "beta", "text": "Jumped over the lazy dog"},
        {"domain": "gamma", "text": "Quick brown animals"},
    ]
    res = map_query("quick brown", logs, top_k=2)
    assert len(res) == 2
    # first result should be the one with both tokens
    assert res[0]["text"] in ("The quick brown fox", "Quick brown animals")
