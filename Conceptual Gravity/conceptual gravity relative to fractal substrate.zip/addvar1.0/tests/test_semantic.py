from src.addvar.semantic import SemanticIndex


def test_semantic_index_basic():
    logs = [
        {"domain": "alpha", "text": "The quick brown fox"},
        {"domain": "beta", "text": "Jumped over the lazy dog"},
        {"domain": "gamma", "text": "Quick brown animals"},
    ]
    si = SemanticIndex(logs)
    # If no models are installed this will raise; test that behavior is explicit.
    try:
        si.build()
    except RuntimeError:
        # Expected if no embedding backend is available in test environment
        assert True
    except Exception:
        assert False
