"""Legacy adapters package"""
