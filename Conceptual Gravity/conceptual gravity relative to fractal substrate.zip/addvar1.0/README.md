# addvar — AI Voice Chat Assistant (scaffold)

This is a minimal scaffold for the "addvar" AI voice-chat assistant. It includes a small FastAPI service to accept logs and map tangents (simple keyword overlap mapper), a voice I/O stub, test, and a VS Code `launch.json` for debugging.

Quick start (Windows PowerShell):

1. Create a virtual environment and activate it:

```powershell
python -m venv .venv; .\.venv\Scripts\Activate.ps1
```

2. Install dependencies:

```powershell
python -m pip install -r requirements.txt
```

3. Run the app (development):

```powershell
uvicorn src.addvar.main:app --reload
```

4. Run tests:

```powershell
pytest -q
```

Notes:
- This scaffold uses a very simple keyword-overlap mapper as a placeholder. Replace with embeddings or semantic search for production.
- For voice I/O, Windows users may find `pyttsx3` for TTS and `sounddevice`/`portaudio` for audio capture helpful. Some packages may require native dependencies.
